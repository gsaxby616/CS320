//George Saxby
//CS320
//06APR25
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;

public class AppointmentServiceTest {

    private AppointmentService appointmentService;

    @BeforeEach
    public void setUp() {
        appointmentService = new AppointmentService();
    }

    @Test
    public void testAddValidAppointment() {
        Appointment appointment = new Appointment("ID001", new Date(System.currentTimeMillis() + 10000), "Description");
        appointmentService.addAppointment(appointment);
        assertEquals(1, appointmentService.getAppointments().size());
    }

    @Test
    public void testAddAppointmentWithDuplicateIDThrowsException() {
        Appointment appt1 = new Appointment("DUPLICATE", new Date(System.currentTimeMillis() + 10000), "First");
        Appointment appt2 = new Appointment("DUPLICATE", new Date(System.currentTimeMillis() + 20000), "Second");

        appointmentService.addAppointment(appt1);
        assertThrows(IllegalArgumentException.class, () -> appointmentService.addAppointment(appt2));
    }

    @Test
    public void testDeleteExistingAppointmentById() {
        Appointment appointment = new Appointment("DEL123", new Date(System.currentTimeMillis() + 10000), "Delete me");
        appointmentService.addAppointment(appointment);
        appointmentService.deleteAppointment("DEL123");
        assertEquals(0, appointmentService.getAppointments().size());
    }

    @Test
    public void testDeleteNonExistingAppointmentThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> appointmentService.deleteAppointment("FAKEID"));
    }

    @Test
    public void testMultipleAppointmentsAddedSuccessfully() {
        Appointment appt1 = new Appointment("ID1", new Date(System.currentTimeMillis() + 10000), "One");
        Appointment appt2 = new Appointment("ID2", new Date(System.currentTimeMillis() + 20000), "Two");

        appointmentService.addAppointment(appt1);
        appointmentService.addAppointment(appt2);

        assertEquals(2, appointmentService.getAppointments().size());
    }
}