//George Saxby
// CS-320
//30MAR25
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.NoSuchElementException;

public class TaskServiceTest {
    private TaskService taskService;

    @BeforeEach
    public void setup() {
        taskService = new TaskService();
    }

    // ADD TASK – PASSING
    @Test
    public void addValidTask() {
        taskService.addTask("1", "Task 1", "Description 1");
    }

    // ADD TASK – FAILING (Duplicate ID)
    @Test
    public void addDuplicateTaskShouldFail() {
        taskService.addTask("1", "Task 1", "Description 1");

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask("1", "Task 2", "Another Description");
        });

        assertEquals("Task ID already exists", exception.getMessage());
    }

    //DELETE TASK – PASSING
    @Test
    public void deleteExistingTask() {
        taskService.addTask("1", "Task 1", "Description 1");
        taskService.deleteTask("1");
        assertThrows(NoSuchElementException.class, () -> {
            taskService.updateTask("1", "New Name", "New Desc");
        });
    }

    //DELETE TASK – FAILING
    @Test
    public void deleteNonExistingTaskShouldNotThrow() {
        assertDoesNotThrow(() -> {
            taskService.deleteTask("999");
        });
    }

    //UPDATE TASK – PASSING
    @Test
    public void updateExistingTask() {
        taskService.addTask("1", "Task 1", "Description 1");
        taskService.updateTask("1", "Updated Name", "Updated Description");
    }

    //UPDATE TASK – FAILING (Task does not exist)
    @Test
    public void updateNonExistingTaskShouldFail() {
        Exception exception = assertThrows(NoSuchElementException.class, () -> {
            taskService.updateTask("999", "Name", "Desc");
        });

        assertEquals("Task ID does not exist", exception.getMessage());
    }

    //UPDATE TASK – FAILING (Invalid name)
    @Test
    public void updateTaskWithInvalidNameShouldFail() {
        taskService.addTask("1", "Task 1", "Description 1");

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTask("1", null, "Valid Description");
        });

        assertEquals("Invalid Name", exception.getMessage());
    }

    //UPDATE TASK – FAILING (Invalid description)
    @Test
    public void updateTaskWithInvalidDescriptionShouldFail() {
        taskService.addTask("1", "Task 1", "Description 1");

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTask("1", "Valid Name", null);
        });

        assertEquals("Invalid Description", exception.getMessage());
    }
}
