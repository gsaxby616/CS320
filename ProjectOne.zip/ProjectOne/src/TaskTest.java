//George Saxby
// CS-320
//30MAR25
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TaskTest {

 // PASSING CASES

    @Test
    public void createValidTask() {
        Task task = new Task("1", "Task 1", "Description 1");
        assertEquals("1", task.getTaskId());
        assertEquals("Task 1", task.getName());
        assertEquals("Description 1", task.getDescription());
    }

    @Test
    public void setNameValid() {
        Task task = new Task("1", "Task 1", "Description 1");
        task.setName("Updated Name");
        assertEquals("Updated Name", task.getName());
    }

    @Test
    public void setDescriptionValid() {
        Task task = new Task("1", "Task 1", "Description 1");
        task.setDescription("Updated Description");
        assertEquals("Updated Description", task.getDescription());
    }

    //FAILING CASES

    @Test
    public void createTaskWithLongIdShouldFail() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Task 1", "Description 1"); // 11 chars
        });
        assertEquals("Invalid Task ID", exception.getMessage());
    }

    @Test
    public void createTaskWithNullIdShouldFail() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Task 1", "Description 1");
        });
        assertEquals("Invalid Task ID", exception.getMessage());
    }

    @Test
    public void setNameTooLongShouldFail() {
        Task task = new Task("1", "Task 1", "Description 1");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            task.setName("This name is definitely more than twenty characters");
        });
        assertEquals("Invalid Name", exception.getMessage());
    }

    @Test
    public void setNameNullShouldFail() {
        Task task = new Task("1", "Task 1", "Description 1");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            task.setName(null);
        });
        assertEquals("Invalid Name", exception.getMessage());
    }

    @Test
    public void setDescriptionTooLongShouldFail() {
        Task task = new Task("1", "Task 1", "Description 1");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription("This description is definitely more than fifty characters long and should fail.");
        });
        assertEquals("Invalid Description", exception.getMessage());
    }

    @Test
    public void setDescriptionNullShouldFail() {
        Task task = new Task("1", "Task 1", "Description 1");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription(null);
        });
        assertEquals("Invalid Description", exception.getMessage());
    }
}
