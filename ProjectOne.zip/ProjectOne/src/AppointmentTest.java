//George Saxby
//CS320
//06APR25
import org.junit.Test;
import java.util.Date;
import static org.junit.Assert.*;

public class AppointmentTest {

    @Test
    public void testValidAppointmentId() {
        Appointment appt = new Appointment("VALIDID", new Date(System.currentTimeMillis() + 10000), "Description");
        assertEquals("VALIDID", appt.getAppointmentId());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAppointmentIdTooLong() {
        new Appointment("TOOLONG12345", new Date(System.currentTimeMillis() + 10000), "Description");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAppointmentIdNull() {
        new Appointment(null, new Date(System.currentTimeMillis() + 10000), "Description");
    }

    @Test
    public void testValidAppointmentDate() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000);
        Appointment appt = new Appointment("DATEPASS", futureDate, "Description");
        assertEquals(futureDate, appt.getAppointmentDate());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAppointmentDateInPast() {
        Date pastDate = new Date(System.currentTimeMillis() - 10000);
        new Appointment("DATEFAIL", pastDate, "Description");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAppointmentDateNull() {
        new Appointment("DATENULL", null, "Description");
    }

    @Test
    public void testValidDescription() {
        String desc = "Valid short description.";
        Appointment appt = new Appointment("DESCPASS", new Date(System.currentTimeMillis() + 10000), desc);
        assertEquals(desc, appt.getDescription());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDescriptionTooLong() {
        String longDesc = "This description is way too long and exceeds fifty characters.";
        new Appointment("DESCFAIL", new Date(System.currentTimeMillis() + 10000), longDesc);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDescriptionNull() {
        new Appointment("DESCNULL", new Date(System.currentTimeMillis() + 10000), null);
    }

    @Test
    public void testFieldsAreNotUpdatable() {
        Appointment appointment = new Appointment("IMMUTABLE", new Date(System.currentTimeMillis() + 10000), "Fixed");
        assertEquals("IMMUTABLE", appointment.getAppointmentId());
        assertEquals("Fixed", appointment.getDescription());
    }
}